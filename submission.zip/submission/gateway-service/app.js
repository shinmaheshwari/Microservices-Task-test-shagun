const express = require('express');
const axios = require('axios');
const app = express();

app.use(express.json());
const port = 3003;

app.get('/', (req, res) => {
  res.send('Gateway Service is running ✅');
});

app.get('/health', (req, res) => {
  res.json({ status: 'Gateway Service is healthy' });
});

app.get('/api/users', async (req, res) => {
  try {
    const response = await axios.get('http://user-service:3000/users');
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching users' });
  }
});

app.get('/api/products', async (req, res) => {
  try {
    const response = await axios.get('http://product-service:3001/products');
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching products' });
  }
});

app.listen(port, () => {
  console.log(`Gateway service running on port ${port}`);
});
